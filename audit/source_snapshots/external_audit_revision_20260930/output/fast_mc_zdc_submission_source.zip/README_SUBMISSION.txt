Manuscript source package, version 0.16.0, 30 September 2026

Entry point: main.tex. Requires pdfLaTeX, biblatex/Biber, and the packages listed in main.tex.
Build: pdflatex -interaction=nonstopmode -halt-on-error main.tex
       biber main
       pdflatex -interaction=nonstopmode -halt-on-error main.tex
       pdflatex -interaction=nonstopmode -halt-on-error main.tex

main.bbl is included from the verified build; regenerate it with Biber when needed.
The four figures are included as the exact verified PNG assets.
This is a compilation package, not the complete evidence/reproduction repository.
The included audit binds the reviewed PDF and full repository sources; some evidence files named there are in the full repository only.
The paper presents a descriptive pilot study and discloses its unresolved scientific limitations.
No journal-specific format is assumed; no submission or public release is performed by this package.
